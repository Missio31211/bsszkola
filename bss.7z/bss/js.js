let imageIndex = 1;

function changeImage() {
    const image = document.getElementById('product-img1');
    imageIndex = imageIndex === 11 ? 1 : imageIndex + 1;
    image.src = `shelly/${imageIndex}.png`;
    document.getElementById('h1-tekst').textContent = `${imageIndex}`;
}